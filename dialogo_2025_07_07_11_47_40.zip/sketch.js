// Variáveis para armazenar a imagem e os diálogos

let imagem;

let dialogo = [];

let personagem1 = "Rafaeli";

let personagem2 = "Ingrid";

let indiceDialogo = 0;

// Pré-carregar a imagem

function preload() {

  imagem = loadImage('Rafa.jpg');

}

function setup() {

  createCanvas(800, 600);

  

  // Definir os diálogos

  dialogo.push({ personagem: personagem1, texto: "Olá me chamo Rafaeli,sou uma aluna que estuda no colégio Albano Guimarães Martins de Reserva Paraná! " });

  dialogo.push({ personagem: personagem1, texto: "Esse meu projeto é sobre de um diálogo com uma colega do nosso colégio que está participando do projeto ganhado mundo!  " });

  
  dialogo.push({ personagem: personagem1, texto: "Como ela está estudando na cidade, e a nossa escola é do campo achei que seria interessante, espero que gostem!" });
  
  dialogo.push({ personagem: personagem1, texto: "Olá Ingrid tudo bem com você?" });
 

  dialogo.push({ personagem: personagem2, texto: "Olá Rafaeli tudo bem sim e com você😁? " });

  dialogo.push({ personagem: personagem1, texto: " Estou bem também! Queria fazer alguma perguntas pra você de como está sendo estudar aí na cidade do Canadá 🇨🇦?" });

  dialogo.push({ personagem: personagem2, texto: " A esperência é muito boa poder conhecer um novo país e uma nova cultura uma linguagem diferente é algo muito legal ❄️" });

  dialogo.push({ personagem: personagem2, texto: "Não á muita diferença más aqui como é uma escola paricular você tem acesso a aulas que abrem carreiras futuramente! 🏫"});
    
  dialogo.push({ personagem: personagem2, texto: "Não que no Brasil não seja possível abrir careiras mais,é que aqui as aulas são mais dinâmicas e é uma experiência muito legal" });

  dialogo.push({ personagem: personagem1, texto: "Aí que bom que você está gostando de participar desse projeto que você conseguiu participar com seus esforços☺️!" });

  dialogo.push({ personagem: personagem1, texto:"Nós estamos ansiosos esperando você volta da sua viagem!🙃 "});

  dialogo.push({ personagem: personagem2, texto: "Eu estou participando de um projeto incrível mas também estou ansiosa pra volta pra casa e ver minha família"});

  dialogo.push({ personagem: personagem2, texto: "Como a nosssa linguagem é diferente eu estou me esforçando bastante aqui pra poder falar em inglês!" });

  dialogo.push({ personagem: personagem1, texto: "Você está sentindo falta de estudar aqui na nossa escola do campo?" });

  dialogo.push({ personagem: personagem2, texto: "As vezes sinto falta do ambiente do campo que é mais tranquilo e dos meu amigos🌻☘️!" });
  dialogo.push({ personagem: personagem1, texto: " Que bom q você está gostando de participar desse projeto ser uma intercambista!"});

  dialogo.push({ personagem: personagem1, texto: "Isso é maravilhoso tenho certeza que você voltará com muitas histórias e aprendizados valiosos!"});

  dialogo.push({ personagem: personagem2, texto: "Espero que sim Rafaeli, eu estou ansiosa pra reencontrar todos e compartilhar as experiências que estou vivendo"});

  dialogo.push({ personagem: personagem1, texto: "Enfim  foi um prazer conversar com você Ingrid" });
   dialogo.push({ personagem: personagem1, texto: " Um abraço pra você se cuida tchau Ingrid 🇨🇦🤗 " });
  dialogo.push({ personagem: personagem2, texto: "Tchau pra você também Rafeli se cuida 🫶🇧🇷" });

  dialogo.push({ personagem: personagem1, texto: "🇧🇷/🇨🇦" });

}
function draw() {

  background(220);

  

  // Desenhar a imagem

  image(imagem, 0, 0, width, height);

  

  // Desenhar o diálogo

  fill(255);

  rect(50, height - 65, width - 100, 20);

  fill(0);

  textSize(10);

  text(dialogo[indiceDialogo].personagem + ": " + dialogo[indiceDialogo].texto, 80, height - 50);

}

// Avançar o diálogo ao clicar

function mousePressed() {

  indiceDialogo++;

  if (indiceDialogo >= dialogo.length) {

    indiceDialogo = 0;

  }

}